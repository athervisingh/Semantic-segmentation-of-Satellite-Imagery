import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { selectCurrentUser } from '../../store/user/user.selector';
import { toggle } from '../../store/Slices/ButtonSlice/buttonSlice';
import { toast } from 'sonner';
import { setModelThreshold } from '../../store/Slices/DataSlice/dataSlice';

const DeveloperSwitch = ({ setAuthPop, setActivePanel, isMobileView }) => {
  const { developerState } = useSelector((state) => state.buttonSlice);
  const dispatch = useDispatch();
  const currentUser = useSelector(selectCurrentUser);

  const handleSwitchDeveloper = () => {
    dispatch(toggle('developerState')); // Pass the property name, not the value
    setActivePanel(prev => prev === 'settings' ? null : prev);
    if (developerState) {
      toast.info('Developer Mode is Off');
      dispatch(setModelThreshold(null));
    } else {
      toast.info('Developer Mode is On');
      dispatch(setModelThreshold({
        modelName: "Mahalanobis Model",
        thresholdValues: [5, 5, 5],
      }));
    }
  };

  useEffect(() => {
    if (isMobileView && !developerState) {
      dispatch(toggle('developerState'));
      setActivePanel(prev => prev === 'settings' ? null : prev);
      dispatch(setModelThreshold({
        modelName: "Mahalanobis Model",
        thresholdValues: [5, 5, 5],
      }));
    }
  }, [isMobileView, developerState, dispatch, setActivePanel]);

  return (
    <>
      {!isMobileView ? (
        <div
          className="absolute inline-block w-12 mr-2 align-middle transition duration-200 ease-in z-[5000] right-16 top-4"
          onClick={handleSwitchDeveloper}
          title='developer mode'
        >
          <input
            type="checkbox"
            className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-gray-900 border-4 appearance-none cursor-pointer"
            checked={developerState}
            readOnly
          />
          <label
            className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-700 cursor-pointer"
          ></label>
        </div>
      ) : null}
    </>
  );
};

export default DeveloperSwitch;
