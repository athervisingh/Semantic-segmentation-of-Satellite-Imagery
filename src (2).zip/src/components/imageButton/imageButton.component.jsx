
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import Button from "../button/button.component"; // Assuming you have a Button component
import { changeButton } from "../../store/Slices/ButtonSlice/buttonSlice"; // Your Redux action for button states
// import {useEffect,useState} from "react";
import { setImageData } from "../../store/Slices/DataSlice/dataSlice";
import { sendSignalforButtonResponse } from "../../store/Slices/AdditionalDetailsSlice/addDetailsSlice";
const ImageButton = () => {
  const dispatch = useDispatch();
  const geojsonData = useSelector((state) => state.geojsonData);
  var geo = JSON.parse(JSON.stringify(geojsonData));
  // const { mapInstance } = useSelector((state) => state.dataSlice); // Assuming you have a Mapbox map initialized elsewhere in your code
  // const map = mapInstance;

  const {bandValues, date} = useSelector((state)=> state.addDetailsSlice)
  // useEffect(() => {
  //   if (map) {
  //     const geeTileUrl = `https://earthengine.googleapis.com/v1/projects/earthengine-legacy/maps/4f476dbbd9f6aa3178ae69575d22ec46-04c53f50c4fcaba55c445c9f73bbb31c/tiles/{z}/{x}/{y}?access_token=ya29.c.c0ASRK0GZKMcyh-we8TTmAjZfZ9O9XPaDwnlEUKY5x7gHZ92CCw442Hl4NSgA9UloLFcrSa7b-p98DC0zR5inJFwLfnvCJNXKblTQdBsLC-l0srw50CWq7x9xoXyG6dPXMT3dFl7BIoOYT64L03jZaQwVSictuVUS4tEo6nUpmEjbNNs5xFwnHzNUba2ddOHgrYkEtx-efG-rHxc3giRX6XlwbZplKOtTWju0DsehGPjF5531Ta4eC1W7i74W2TglsAODyycC7g3WyvFfj3DeLkhjqnjxep8jWA0E6lrfl3vbTXQXym93hPI0FFSVPsz8jxdx7evOBRZm09AmAbnbCsulZXrXudqoJE3vXns088zdwJpw8MLIC07AH384D55czRZ_pzrJb1JXgi7VlzbORxJyFhuYVapmzB8jkrR0iZ8k-IdVdVS7yfRfZaYx0wepkR9vRB23Jn3w-kSYz9pqXshZm1Um-8mmuxaUXIewyFtr6qx5xYSYShJgQYW1hidf6q22omep8l8vYnmO-md4s7WIOrim80egq-Zolh21s_i4q7wlQaeZ2vsvgiWdW4hBkworge6JRXZYOWydYhkqZrydV4J3Yj_doJ1RYQ-rs2VpWtgbc38tpfeoF4dgamUdmw0Rgfio2-969_9_4vM1m032R2l_szYZZidjXpaWX4QUcazwMZy-pamZUVr553cofxf62Y7OkSe8baquVacminr74ceZbiS851wUz929mpUYiup3Wo_hauQU3w41rMb64tI5zRkiWFUBeQ5wx-9YXe5arxVkMQFkeXXZa2X7sMaB-O6xl6vZhz2Q92khf0QbFISemUh5s8mXcBSBmIdMOifeY9v77YpFbhIj_8p0Q5t82oppWQ-0Qb-azxn58ijlVqWsc88MSkI0e7QfaiXoWFR2mk_d5yckqdIF8iQUs2tZgf_ieyhsUeqVsgFMIsZjVYz166wsgv7SuMXVdkcZxn3bkJdfZ2ehdQ8VmluXrfvJlhxxO0f9`;
  //   map.on("load", () => {
  //     // Add custom overlay (optional)
  //     map.addSource("custom-overlay", {
  //       type: "raster",
  //       tiles: [geeTileUrl],
  //       tileSize: 256,
  //     });

  //     map.addLayer({
  //       id: "custom-overlay-layer",
  //       type: "raster",
  //       source: "custom-overlay",
  //       paint: {
  //         "raster-opacity": 1, 
  //       },
  //     });
  //   });
  // }
  // return () => {
  //   if (map && map.destroy) {
  //     map.remove(); // Clean up properly
  //   }
  // };
   
  // }, [map]);

  const sendGeoJsonData = async () => {
    
    try {
      const combinedData = geo.length === 0 
      ? { 
          bands: bandValues, 
          date: date 
        } 
      : { 
          geojson: geo.geojsonData, 
          bands: bandValues, 
          date: date 
        };  

      console.log("Sending data to backend:", combinedData);

   const response =   await axios.post("https://8z2h0gbj-5001.inc1.devtunnels.ms/images", combinedData, {
        // timeout: 10000,
        withCredentials: true,
        headers: {
          "Content-Type": "application/json",
        },
      });


      console.log("response",response.data)
      const { image_url, access_token } = response.data;

      dispatch(setImageData({ image_url, access_token }));
      dispatch(sendSignalforButtonResponse(true))
      // setGeeImageUrl(image_url);
      // setGeeAccessToken(access_token);
      dispatch(changeButton({ type: "enableClasses", payload: true }));
      dispatch(changeButton({ type: "showImageButton", payload: false }));
    } catch (error) {
      console.error("Error:", error);
      alert("An unknown error occurred.");
    }
  };

  const handleClick = () => {
    console.log("ImageButton clicked!");
    sendGeoJsonData();
  };

  return (
    <div className="absolute bottom-0 left-[2%] z-[1000]" onClick={handleClick}>
      <Button label={"Image"} />
    </div>
  );
};

export default ImageButton;
