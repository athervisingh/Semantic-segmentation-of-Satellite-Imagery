import React, { useState } from 'react';
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Slider,
  IconButton,
  Box,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';

const OpacitySlider = ({ overlayIndex, opacitySlider, imageData, handleSliderChange }) => {
  const [expanded, setExpanded] = useState(false);

  if (!opacitySlider || !imageData) return null;

  const handleAccordionToggle = () => setExpanded(!expanded);

  const handleChange = (name, delta) => {
    handleSliderChange(name, delta, overlayIndex);
  };

  return (
    <Accordion
      expanded={expanded}
      onChange={handleAccordionToggle}
      sx={{
        backgroundColor: 'transparent', // Transparent background
        boxShadow: 'none',
        padding: 'none' , // Removes shadow for a cleaner look
        // border: '1px solid rgba(255, 255, 255, 0.1)', // Optional border for better visibility
      }}
    >
      <AccordionSummary expandIcon={<ExpandMoreIcon className='text-white'/>}>
        <Typography variant="subtitle2" fontWeight="600" fontSize={20} color='white'  >
          Opacity Controls
        </Typography>
      </AccordionSummary>
      <AccordionDetails sx={{
        color: 'white'
      }} >
        {Object.keys(imageData).map((name) => (
          <Box key={name} sx={{ mb: 2 }}>
            <Typography variant="body2" fontWeight="500">
              Class: {name}
            </Typography>
            <Box display="flex" alignItems="center">
              <Slider
                value={imageData[name]?.opacity || 0}
                onChange={(e, value) => handleChange(name, value - imageData[name]?.opacity)}
                step={0.01}
                min={0}
                max={1}
                sx={{ flex: 1 }}
              />
              <IconButton
                size="small"
                onClick={() => handleChange(name, -0.1)}
                disabled={imageData[name]?.opacity <= 0}
                
              >
                <RemoveIcon fontSize="small" sx={{
                  color :'white'
                }} />
              </IconButton>
              <IconButton
                size="small"
                onClick={() => handleChange(name, 0.1)}
                disabled={imageData[name]?.opacity >= 1}
              >
                <AddIcon fontSize="small" sx={{
                  color: 'white'
                }} />
              </IconButton>
            </Box>
            <Typography variant="caption">
              Area: {imageData[name]?.area || 0} km<sup>2</sup>
            </Typography>
          </Box>
        ))}
      </AccordionDetails>
    </Accordion>
  );
};

export default OpacitySlider;
