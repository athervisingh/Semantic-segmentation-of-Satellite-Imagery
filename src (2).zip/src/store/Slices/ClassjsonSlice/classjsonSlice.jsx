import { createSlice } from '@reduxjs/toolkit';

const classJsonSlice = createSlice({
  name: 'classjsonData',
  initialState: {
    properties:null, // Array of objects
    classjsonData: [], // Array of objects
  },
  reducers: {
    addClassPolygon: (state, action) => {
      console.log("BEFORE -----------------:", JSON.parse(JSON.stringify(state)));
      const newPolygon = {
        ...action.payload,
        properties: state.properties,
      };

      state.classjsonData.push(newPolygon);

      console.log("AFTER -----------------:", JSON.parse(JSON.stringify(state.classjsonData)));
    },
    addClassProperties: (state, action) => {
      console.log("BEFORE -----------------:", JSON.parse(JSON.stringify(state)));
        state.properties =action.payload; 
    
      console.log("AFTER -----------------:", JSON.parse(JSON.stringify(state)));

    },
    clearClassAll: (state) => {
      state.properties = [];
      state.geojsonData = [];
    },
  },
});

export const { addClassPolygon, addClassProperties, clearClassAll } = classJsonSlice.actions;
export default classJsonSlice.reducer;
