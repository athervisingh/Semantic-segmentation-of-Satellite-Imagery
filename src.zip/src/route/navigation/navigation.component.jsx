import { useState, useEffect, useRef } from "react";
import { Outlet, NavLink, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import { LogIn, UserPlus, Menu, X } from "lucide-react";
import { selectCurrentUser } from "../../store/user/user.selector";
import ROIdropdown from "../../components/dropdown/roiDropdown.component";
import ColorDropdown from "../../components/colorPalatteDropdown/colorDropdown.component";
import states from "../../../data/INDIAN_STATE.js";
import UserLog from "./userAndLogout.component.jsx";
import ClassDropdown from "../../components/dropdown/classDropdown.component.jsx";

const Navigation = () => {
  const [isMobileView, setIsMobileView] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const checkWidth = () => {
    if (window.innerWidth <= 746) {
      setIsMobileView(true);
    } else {
      setIsMobileView(false);
      setIsMenuOpen(false); // Close menu on desktop view
    }
  };

  useEffect(() => {
    checkWidth(); // Check initial window size
    window.addEventListener("resize", checkWidth); // Listen for resize events

    return () => {
      window.removeEventListener("resize", checkWidth);
    };
  }, []);

  const { enableClasses, enableROI } = useSelector((state) => state.buttonSlice);
  const currentUser = useSelector(selectCurrentUser);
  const location = useLocation();

  const isAuthRoute =
    location.pathname === "/auth/sign-in" ||
    location.pathname === "/auth/sign-up" ||
    location.pathname === "/forgot-password";

  return (
    <div className="bg-bg-color shadow-lg border-b border-gray-700 h-[8.5vh] w-full relative ">
      <div className="max-w-[88%] mx-auto items-center px-4 h-full relative flex justify-between">
        <div className="flex items-center gap-4">
          <img src="/logo.png" alt="logo" className="w-10 h-10 invert" />
           <h1 className="text-white text-xl font-semibold">Prithview</h1>
        </div>

        {!isAuthRoute && (
          <>
            {!isMobileView ? (
              <div className="flex gap-6 items-center">
                <div className="relative flex gap-2">
                  <ROIdropdown />
                  <ColorDropdown isROI={true} />
                </div>
                <div className="relative flex gap-2">
                  <ClassDropdown />
                  <ColorDropdown isROI={false} />
                </div>
                {currentUser ? (
                  <UserLog />
                ) : (
                  <div className="min-w-[5rem] max-w-[10rem] flex gap-2">
                    <NavLink
                      to="/auth/sign-up"
                      className="text-gray-400 hover:text-white"
                    >
                      Register
                    </NavLink>
                    <span className="text-gray-400">or</span>
                    <NavLink
                      to="/auth/sign-in"
                      className="text-gray-400 hover:text-white"
                    >
                      Sign In
                    </NavLink>
                  </div>
                )}
              </div>
            ) : (
              <button
                className="text-white"
                onClick={() => setIsMenuOpen((prev) => !prev)}
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            )}
          </>
        )}
      </div>

      {/* Mobile Menu */}
      {isMobileView && isMenuOpen && (
        <div className="absolute top-[8vh] left-0 w-full bg-bg-color z-10 flex flex-col items-start p-4 space-y-4">
          <ROIdropdown />
          <ClassDropdown />
          {currentUser ? (
            <UserLog />
          ) : (
            <div className="flex flex-col gap-2">
              <NavLink
                to="/auth/sign-up"
                className="text-gray-400 hover:text-white"
              >
                Register
              </NavLink>
              <NavLink
                to="/auth/sign-in"
                className="text-gray-400 hover:text-white"
              >
                Sign In
              </NavLink>
            </div>
          )}
        </div>
      )}

      <Outlet />
    </div>
  );
};

export default Navigation;
