import { useEffect } from "react";
import mapboxgl from "mapbox-gl";
import MapboxGeocoder from "@mapbox/mapbox-gl-geocoder";
import MapboxDraw from "@mapbox/mapbox-gl-draw";
import { setMapInstance } from "../../store/Slices/DataSlice/dataSlice";
import extendDrawBar from "../extend_bar";
import DrawRectangle from "../DrawRectangle";
import "mapbox-gl/dist/mapbox-gl.css";
import "@mapbox/mapbox-gl-geocoder/dist/mapbox-gl-geocoder.css";
import "@mapbox/mapbox-gl-draw/dist/mapbox-gl-draw.css";
import { useDispatch, useSelector } from "react-redux";

const TilesLayer = ({ map, setMap, currentStyle }) => {
  const dispatch = useDispatch();
  const { geeImageUrl, geeAccessToken } = useSelector(
    (state) => state.dataSlice
  );
  const buttons = useSelector((state) => state.buttonSlice);
  const { dropdownData } = useSelector((state) => state.dataSlice);

  const MAP_BOX =
    "pk.eyJ1Ijoia2hhbGVlcXVlNTYiLCJhIjoiY200NXphMDg2MHZzODJxc2Jha3F5N3VnYiJ9.oEzy-505dRBcBamWC6QOqA";
  const ACCESS_TOKEN =
    "pk.eyJ1Ijoic3ZjLW9rdGEtbWFwYm94LXN0YWZmLWFjY2VzcyIsImEiOiJjbG5sMnExa3kxNTJtMmtsODJld24yNGJlIn0.RQ4CHchAYPJQZSiUJ0O3VQ";

  console.log("drawContorl", buttons.drawControl);

  useEffect(() => {
    mapboxgl.accessToken = MAP_BOX;

    let zoom = 2, lat = 0, lon = 0;
    try {
      const mapFragment = window.location.hash.split("#map=")[1];
      if (mapFragment) {
        const parts = mapFragment.split("/");
        zoom = parseFloat(parts[0]) || 2;
        lat = parseFloat(parts[1]) || 0;
        lon = parseFloat(parts[2]) || 0;
      }
    } catch {
      console.log("Initializing default map settings.");
    }

    const mapInstance = new mapboxgl.Map({
      container: "map",
      style: currentStyle,
      center: [lat, lon],
      zoom,
      projection: "globe",
      hash: "map",
    });

    mapInstance.addControl(
      new MapboxGeocoder({
        accessToken: ACCESS_TOKEN,
        mapboxgl,
        marker: true,
      })
    );
    console.log("GEE URL", geeImageUrl, geeAccessToken);
    const geeTileUrl = `${geeImageUrl}?access_token=${geeAccessToken}`;

    mapInstance.on("load", () => {
      mapInstance.setFog({
        range: [0.1, 0.9],
        color: "rgb(0, 0, 0)",
        "horizon-blend": 0.02,
      });

      if (geeImageUrl !== null && geeAccessToken!== null) {
        mapInstance.addSource("custom-overlay", {
          type: "raster",
          tiles: [geeTileUrl],
          tileSize: 256,
        });
  
        mapInstance.addLayer({
          id: "custom-overlay-layer",
          type: "raster",
          source: "custom-overlay",
          paint: {
            "raster-opacity": 1,
          },
        });
      }
    });

    mapInstance.addControl(new mapboxgl.NavigationControl());
    setMap(mapInstance);
    dispatch(setMapInstance(mapInstance));

    return () => {
      mapInstance.remove(); // Cleanup on unmount
    };
  }, [currentStyle, setMap, dispatch, geeImageUrl, geeAccessToken]);

 const geojsonData = useSelector((state)=>state.geojsonData)
  useEffect(() => {
    if (map) {
      const modes = MapboxDraw.modes;
     
      modes.draw_rectangle_roi = DrawRectangle(dispatch, true);
      modes.draw_rectangle_class = DrawRectangle(dispatch, false);

      const draw = new MapboxDraw({
        displayControlsDefault: false,
        controls: {
          draw_rectangle_roi: DrawRectangle,
          draw_rectangle_class: DrawRectangle,
          direct_select: MapboxDraw.modes.direct_select,
        },
        modes: modes,
      });

      const drawControl = new extendDrawBar({
        draw: draw,
        buttons: [
          {
            on: "click",
            action: () => {
              draw.changeMode("draw_point");
            },
            classes: ["mapbox-gl-draw_ctrl-draw-btn", "mapbox-gl-draw_point"],
            title: "Draw Point (m)",
          },
          {
            on: "click",
            action: () => {
              // Assuming you have access to the draw instance
              draw.changeMode('draw_rectangle'); // Activate DrawRectangle mode
              draw.onTrash();

            },
            classes: ["mapbox-gl-draw_ctrl-draw-btn", "mapbox-gl-draw_polygon"],
            title: "Draw Polygon (p)",
          },
          {
            on: "click",
            action: () => {
              draw.changeMode("draw_rectangle_roi");
            },
            classes: [
              "mapbox-gl-draw_ctrl-draw-btn",
              "mapbox-gl-draw_rectangle",
            ],
            title: "Draw Rectangle for ROI",
          },
          {
            on: "click",
            action: () => {
              draw.changeMode("draw_rectangle_class");
            },
            classes: [
              "mapbox-gl-draw_ctrl-draw-btn",
              "mapbox-gl-draw_rectangle",
            ],
            title: "Draw Rectangle for Class",
          },
          {
            on: "click",
            action: () => {
              draw.deleteAll();
            },
            classes: ["mapbox-gl-draw_ctrl-draw-btn", "mapbox-gl-draw_trash"],
            title: "Trash (t)",
          },
        ],
      });

      map.addControl(drawControl);

      return () => {
        // console.log(drawControl , '<---')
        if (drawControl !== 'off' && map && map !== 'off') {
          map.removeControl(drawControl);
        }
      };
    }
  }, [map, dispatch]);

  return (<div id="map" style={{ width: "100%", height: "100vh" }}>
    {!buttons.drawControl && 
    <div className="absolute left-2 top-[21.5%] h-[19.6%] w-[2.5rem] backdrop-blur-3xl z-[1000] opacity-[0.5] rounded-lg p-[0.3rem]"></div>}
    {!buttons.drawClassControl && (
      <div className="absolute left-2 top-[42.2%] h-[5.8%] w-[2.5rem] backdrop-blur-3xl z-[1000] opacity-[0.5] rounded-lg p-[0.3rem] bsolute"></div>

    
    )}
    
    

  </div>);
};

export default TilesLayer;
