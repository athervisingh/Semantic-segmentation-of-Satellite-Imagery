import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setModelThreshold } from "../../../../store/Slices/DataSlice/dataSlice";

const ThresholdSliders = ({ selectedModel }) => {
  const [hoveredIndex, setHoveredIndex] = useState(null);
  const { developerState } = useSelector((state) => state.buttonSlice);
  const dispatch = useDispatch();
  const { dropdownData } = useSelector((state) => state.dataSlice);

  const classes = dropdownData.map((item) => item.class).filter(Boolean); // Filter out null classes
  const [thresholds, setThresholds] = useState(
    new Array(classes.length).fill(5) // Initial thresholds
  );

  useEffect(() => {
    if (developerState) {
      let thresholdData = null;

      if (selectedModel === "Mahalanobis Model") {
        thresholdData = thresholds; // Dispatch array for Mahalanobis
      } else if (selectedModel === "Maximum LikelyHood") {
        thresholdData = thresholds[0]; // Dispatch single value for Maximum LikelyHood
      }

      dispatch(
        setModelThreshold({
          modelName: selectedModel,
          thresholdValues: thresholdData,
        })
      );
    }
  }, [developerState, selectedModel, thresholds]);

  const handleThresholdChange = (index, value) => {
    const updatedThresholds = [...thresholds];
    updatedThresholds[index] = value;
    setThresholds(updatedThresholds);
  };

  const renderSlider = (index, label, thresholdValue, min = 1, max = 10) => {
    const percentage = ((thresholdValue - min) / (max - min)) * 100;

    return (
      <div
        key={index}
        className="relative group mb-8"
        onMouseEnter={() => setHoveredIndex(index)}
        onMouseLeave={() => setHoveredIndex(null)}
      >
        <div className="text-gray-200 font-medium mb-2">{label}</div>
        <div className="relative">
          <input
            type="range"
            min={min}
            max={max}
            value={thresholdValue}
            onChange={(e) => handleThresholdChange(index, Number(e.target.value))}
            className="w-full h-2 bg-gray-700 rounded-full appearance-none cursor-pointer focus:outline-none"
          />
          {hoveredIndex === index && (
            <div
              className="absolute -top-8 bg-gray-800 text-white px-2 py-1 rounded text-xs font-semibold text-center transform -translate-x-1/2"
              style={{ left: `${percentage}%` }}
            >
              {thresholdValue}
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="rounded-lg">
      <h2 className="text-xl font-semibold mb-6 flex items-center text-gray-100">
        {(selectedModel === "Mahalanobis Model" || selectedModel === "Maximum LikelyHood") &&
          "Threshold Frequency"}
      </h2>
      {selectedModel === "Mahalanobis Model" && (
        <div className="space-y-8">
          {classes.map((className, index) =>
            renderSlider(index, className, thresholds[index])
          )}
        </div>
      )}
      {selectedModel === "Maximum LikelyHood" && (
        <div>
          {renderSlider(0, "Maximum Likelihood", thresholds[0], 1, 15)}
        </div>
      )}
    </div>
  );
};

export default ThresholdSliders;
