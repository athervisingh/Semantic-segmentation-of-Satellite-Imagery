import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import ModelSelector from './settings/modelSelector.component';
import BandConfiguration from './settings/bandConfig.component';
import ThresholdSliders from './settings/thresholdSlider.component';
import DateSelector from './settings/dateSelector.component';
import ReviseData from './settings/reviseData.component';

const MLModelComponent = ({ mapInstance }) => {
  const dispatch = useDispatch();
  const classJsonData = useSelector((state) => state.classjsonData);
  const { showModelThresholdButtons, showBandsDateButtons } = useSelector((state) => state.buttonSlice);
  const [selectedModel, setSelectedModel] = useState('Mahalanobis Model');
  const handleMouseEnter = () => {
    if (mapInstance) {
      mapInstance.dragPan.disable(); // Disable map dragging
      mapInstance.scrollZoom.disable(); // Disable scroll zoom
    }
  };

  const handleMouseLeave = () => {
    if (mapInstance) {
      mapInstance.dragPan.enable(); // Enable map dragging
      mapInstance.scrollZoom.enable(); // Enable scroll zoom
    }
  };
  return (
    <div className="rounded-lg text-gray-100 "
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}>
      <h2 className="text-xl font-semibold mb-4 flex items-center">ML Model Configuration</h2>

      <div className="space-y-4">

        {/* {classJsonData.length > 0 && */}
          <ModelSelector selectedModel={selectedModel} setSelectedModel={setSelectedModel} />
          {/* } */}

        {showBandsDateButtons && classJsonData.length <= 0 &&
          <BandConfiguration />}

        {/* {classJsonData.length > 0 && */}
          <ThresholdSliders selectedModel={selectedModel} />
          {/* } */}

        {showBandsDateButtons && classJsonData.length <= 0 &&
          <DateSelector />}
        
        <ReviseData/>
      </div>
    </div>
  );
};

export default MLModelComponent;
