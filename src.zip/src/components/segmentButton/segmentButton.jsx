import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import Button from "../button/button.component"; // Assuming you have a Button component
import { changeButton } from "../../store/Slices/ButtonSlice/buttonSlice"; // Your Redux action for button states
import { useRef, useEffect } from "react";
const SegmentButton = () => {
  const dispatch = useDispatch();
  const { mapInstance, modelThreshold } = useSelector((state) => state.dataSlice); // Assuming you have a Mapbox map initialized elsewhere in your code
  const classjsonData = useSelector((state) => state.classjsonData); // Assuming you have a Mapbox map initialized elsewhere in your code
  const {modelSelection} = useSelector((state) => state.addDetailsSlice); // Assuming you have a Mapbox map initialized elsewhere in your code
  const map = mapInstance;
  const canvasRef = useRef(null);
  const contextRef = useRef(null);
  const { segmentButtonDisabled } = useSelector((state) => state.buttonSlice);
  const { dropdownData } = useSelector((state) => state.dataSlice);
  const geojsonData = useSelector((state) => state.geojsonData.geojsonData);

  var geo = JSON.parse(JSON.stringify(geojsonData));
  if (geo.length > 0) geo[0].properties = dropdownData[0];
  

  function calculateCanvasDimensions(canvasBounds, scale) {
    // Extract the top-left and bottom-right coordinates from the bounds
    const [topLeftLon, topLeftLat] = canvasBounds[0]; // Top-left [longitude, latitude]
    const [bottomRightLon, bottomRightLat] = canvasBounds[1]; // Bottom-right [longitude, latitude]
    
    // Calculate the width and height of the canvas in degrees (longitude, latitude)
    const canvasWidthInDegrees = bottomRightLon - topLeftLon;
    const canvasHeightInDegrees = topLeftLat - bottomRightLat;
  
    // Define a function to convert degrees to meters (this is a rough conversion)
    function degreesToMeters(degrees) {
      const earthRadius = 6371000; // Earth's radius in meters
      const rad = degrees * (Math.PI / 180);
      return earthRadius * rad;
    }
  
    // Convert the width and height of the canvas in degrees to meters
    const canvasWidthInMeters = degreesToMeters(canvasWidthInDegrees);
    const canvasHeightInMeters = degreesToMeters(canvasHeightInDegrees);
  
    // Now calculate the resolution in pixels (using the scale in meters per pixel)
    const canvasWidthInPixels = canvasWidthInMeters / scale;
    const canvasHeightInPixels = canvasHeightInMeters / scale;
    
    return {canvasWidthInPixels, canvasHeightInPixels};
  }



  function getCanvasBounds(geojson) {
    if (!geojson) {
      throw new Error("Invalid GeoJSON data");
    }
    console.log(geojson)
    console.log(geojsonData)
    // console.log("Updated json:", JSON.parse(JSON.stringify(geojsonData.geojsonData)));
    const coordinates = geojson[0].geometry.coordinates[0];
    console.log(coordinates)
    // const coordinates = geojson;
    if (!coordinates || coordinates.length < 4) {
      throw new Error("Invalid coordinates in GeoJSON data");
    }
  
    // Extract coordinates for the top-left and bottom-right
    const topLeft = coordinates[0]; // First coordinate
    const bottomRight = coordinates[2]; // Third coordinate
  
    return [
      [topLeft[0], topLeft[1]], // Top-left
      [bottomRight[0], bottomRight[1]] // Bottom-right
    ];
  }


  const canvasBounds = getCanvasBounds(geo);

  // const canvasBounds = [
  //   [
  //     75.02557800067922,
  //     24.947601861587046
  //   ], // Top-left
  //   [
  //     76.13585435619927,
  //     24.30404927543755
  //   ],// Bottom-right
  // ];


  useEffect(() => {
    if (!map) {
      console.error("Map instance is null or undefined");
      return;
    }

    const setupCanvas = () => {
      try {
        const canvas = document.createElement("canvas");
        const dimensions = calculateCanvasDimensions(canvasBounds, 30);
        canvas.width = dimensions.canvasWidthInPixels //3703;
        canvas.height = dimensions.canvasHeightInPixels //3723;
        console.log(canvas.width, canvas.height)
        canvasRef.current = canvas;
        contextRef.current = canvas.getContext("2d");

        contextRef.current.clearRect(0, 0, canvas.width, canvas.height);

        // Fill background with semi-transparent red
        contextRef.current.fillStyle = "rgba(255, 0, 0, 0.3)";
        contextRef.current.fillRect(0, 0, canvas.width, canvas.height);

        map.addSource("canvas-source", {
          type: "canvas",
          canvas: canvas,
          coordinates: [
            canvasBounds[0],
            [canvasBounds[1][0], canvasBounds[0][1]],
            canvasBounds[1],
            [canvasBounds[0][0], canvasBounds[1][1]],
          ],
        });

        map.addLayer({
          id: "canvas-layer",
          type: "raster",
          source: "canvas-source",
        });
      } catch (error) {
        console.error("Error setting up canvas:", error);
      }
    };

    const combinedData = {
      classGeojson:classjsonData,
      model:modelSelection,
      threshold: modelThreshold, 
      roi:geo[0]
    };

    console.log(combinedData)


    return () => {
      setupCanvas();
    };
  }, [map,classjsonData,geojsonData]);

  const drawCanvas = (image, top_left, bounds, shape) => {
    console.log(shape)
    const canvas = canvasRef.current;
    const context = contextRef.current;
  
    if (!canvas || !context) {
      console.error("Canvas or context is not initialized.");
      return;
    }

    const img = new Image();
    img.src = `data:image/png;base64,${image}`; // Replace with your image URL or base64
    img.onload = () => {

       // Canvas bounds: Top-left and Bottom-right corners in [longitude, latitude]
      const [canvastopLeftLon, canvastopLeftLat] = bounds[0]; // Top-left [longitude, latitude]
      const [canvasbottomRightLon, canvasbottomRightLat] = bounds[1]; // Bottom-right [longitude, latitude]
      
      // Image bounds: Top-left [longitude, latitude]
      const [imgTopLeftLon, imgTopLeftLat] = top_left; // Image top-left [longitude, latitude]
      console.log(imgTopLeftLon, imgTopLeftLat)
      // Calculate the width and height of the canvas in degrees (longitude, latitude)
      const canvasWidthInDegrees = canvasbottomRightLon - canvastopLeftLon; 
      const canvasHeightInDegrees = canvastopLeftLat - canvasbottomRightLat;
      
      // Get the actual canvas width and height in pixels
      const canvasWidth = canvas.width; 
      const canvasHeight = canvas.height;
      
      // Calculate scale factors (pixels per degree)
      const scaleX = canvasWidth / canvasWidthInDegrees;  // pixels per degree of longitude
      const scaleY = canvasHeight / canvasHeightInDegrees;  // pixels per degree of latitude
      
      // Now calculate the map position of the image's top-left corner in canvas coordinates
      var img_x = (imgTopLeftLon - canvastopLeftLon) * scaleX;
      var img_y = (canvastopLeftLat - imgTopLeftLat) * scaleY;
      
      // Image dimensions in pixels (shape array)
      const imageWidth = shape[1];
      const imageHeight = shape[0];

      console.log(img_x, img_y, imageWidth, imageHeight);
      context.drawImage(img, img_x, img_y, imageWidth, imageHeight);
      img_x = 0;
      img_y = 0;
  };
};



  // Function to send GeoJSON data to the backend
  const sendMaskData = async () => {
    console.log(classjsonData);
    try {
      const combinedData = {
        classGeojson:classjsonData.filter((item, index) => index === 0)[0],
        model:modelSelection,
        threshold: modelThreshold, 
        roi:geo[0]
      };

      console.log("Sending data to backend:", combinedData);

      await axios.post("https://8z2h0gbj-5001.inc1.devtunnels.ms/machine_learning", combinedData, {
        timeout: 10000,
        withCredentials: true,
        headers: {
          "Content-Type": "application/json",
        },
      });

      const eventSource = new EventSource("http://127.0.0.1:5001/machine_learning_stream", {
        withCredentials: true,
      });

      eventSource.onmessage = (event) => {
        try {
          const chunk = JSON.parse(event.data);
          console.log("Received chunk:", chunk);

          // const { top_left, image, shape } = chunk;
          // console.log(top_left, "Top left coord")
          // drawCanvas(image, top_left, canvasBounds, shape);
          // if (chunk.status === "Completed") {
          //   eventSource.close();
          //   console.log("All images loaded.");
          // }

        } catch (error) {
          console.error("Error processing event data:", error);
        }
      };

      eventSource.onerror = (error) => {
        console.error("SSE Error:", error);
        eventSource.close();
        alert("An error occurred while receiving the data.");
      };

      dispatch(changeButton({ type: "enableClasses", payload: true }));
      dispatch(changeButton({ type: "showImageButton", payload: false }));
    } catch (error) {
      console.error("Error:", error);
      alert("An unknown error occurred.");
    }
  };

  const handleClick = () => {
    console.log("ImageButton clicked!");
    sendMaskData();
  };

  return (
    <div className="absolute bottom-0 left-[2%] z-[6001]" onClick={handleClick}>
      <Button label={"Segment"} />
    </div>
  );
};

export default SegmentButton;
